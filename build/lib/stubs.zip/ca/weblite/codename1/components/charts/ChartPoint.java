package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class ChartPoint extends GeomElement {

	public ChartPoint() {
	}

	public ChartPoint radius(Double radius) {
	}

	public Double radius() {
	}

	public ChartPoint.Symbol symbol() {
	}

	public ChartPoint symbol(ChartPoint.Symbol symbol) {
	}

	public static final class Symbol {


		public static final ChartPoint.Symbol CIRCLE;

		public static ChartPoint.Symbol[] values() {
		}

		public static ChartPoint.Symbol valueOf(String name) {
		}

		public String toString() {
		}
	}
}
