package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Point {

	public double x;

	public double y;

	public Point(double x, double y) {
	}
}
