package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Bar extends GeomElement {

	public Bar() {
	}

	public Bar zero(Boolean zero) {
	}

	public Boolean zero() {
	}

	public Bar barWidth(Double barWidth) {
	}

	public Double barWidth() {
	}

	public Bar align(Bar.Align align) {
	}

	public Bar.Align align() {
	}

	public Bar horizontal(Double horizontal) {
	}

	public Double horizontal() {
	}

	public static final class Align {


		public static final Bar.Align LEFT;

		public static final Bar.Align CENTER;

		public static final Bar.Align RIGHT;

		public static Bar.Align[] values() {
		}

		public static Bar.Align valueOf(String name) {
		}

		public String toString() {
		}
	}
}
