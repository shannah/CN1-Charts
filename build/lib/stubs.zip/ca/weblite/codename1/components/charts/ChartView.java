package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class ChartView extends com.codename1.ui.Container {

	public ChartView(Chart model) {
	}

	public void setChartModel(Chart model) {
	}

	public Chart getChartModel() {
	}

	public void initLater(Runnable afterInit) {
	}

	public void initLater() {
	}

	public void initAndWait() {
	}

	public Exception getInitializationException() {
	}

	public void update() {
	}
}
