package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class BorderWidths {

	public BorderWidths(int w) {
	}

	public BorderWidths(int ns, int ew) {
	}

	public BorderWidths(int top, int right, int bottom, int left) {
	}

	public BorderWidths top(Integer top) {
	}

	public Integer top() {
	}

	public BorderWidths bottom(Integer bottom) {
	}

	public Integer bottom() {
	}

	public BorderWidths left(Integer left) {
	}

	public Integer left() {
	}

	public BorderWidths right(Integer right) {
	}

	public Integer right() {
	}
}
