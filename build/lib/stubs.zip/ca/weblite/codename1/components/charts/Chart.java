package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Chart {

	public Chart() {
	}

	public Chart series(java.util.List series) {
	}

	public Chart addSeries(Series series) {
	}

	public Chart removeSeries(Series series) {
	}

	public java.util.List series() {
	}

	public Chart options(Options options) {
	}

	public Options options() {
	}
}
