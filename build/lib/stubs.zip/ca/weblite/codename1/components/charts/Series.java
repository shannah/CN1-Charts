package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Series {

	public Series(double[] points) {
	}

	public Series() {
	}

	public Series add(double[] points) {
	}

	public Series color(Color color) {
	}

	public Color color() {
	}

	public Series data(java.util.List data) {
	}

	public java.util.List data() {
	}

	public Series label(String label) {
	}

	public String label() {
	}

	public Series lines(Line lines) {
	}

	public Line lines() {
	}

	public Series bars(Bar bars) {
	}

	public Bar bars() {
	}

	public Series points(ChartPoint points) {
	}

	public ChartPoint points() {
	}

	public Series xAxis(Integer xAxis) {
	}

	public Integer xAxis() {
	}

	public Series yAxis(Integer yAxis) {
	}

	public Integer yAxis() {
	}

	public Series clickable(Boolean clickable) {
	}

	public Boolean clickable() {
	}

	public Series hoverable(Boolean hoverable) {
	}

	public Boolean hoverable() {
	}

	public Series shadowSize(Double shadowSize) {
	}

	public Double shadowSize() {
	}

	public Series highlightColor(Color highlightColor) {
	}

	public Color highlightColor() {
	}

	public Series pie(PieOptions pie) {
	}

	public PieOptions pie() {
	}
}
