package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class BorderColors {

	public BorderColors(Color c) {
	}

	public BorderColors(Color ns, Color ew) {
	}

	public BorderColors(Color top, Color right, Color bottom, Color left) {
	}

	public BorderColors top(Color top) {
	}

	public Color top() {
	}

	public BorderColors right(Color right) {
	}

	public Color right() {
	}

	public BorderColors bottom(Color bottom) {
	}

	public Color bottom() {
	}

	public BorderColors left(Color left) {
	}

	public Color left() {
	}
}
