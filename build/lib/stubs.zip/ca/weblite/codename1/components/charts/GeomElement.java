package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class GeomElement {

	public GeomElement() {
	}

	public GeomElement show(Boolean show) {
	}

	public Boolean show() {
	}

	public GeomElement lineWidth(Integer lineWidth) {
	}

	public Integer lineWidth() {
	}

	public GeomElement fill(Boolean fill) {
	}

	public Boolean fill() {
	}

	public GeomElement fillColor(Color fillColor) {
	}

	public Color fillColor() {
	}
}
