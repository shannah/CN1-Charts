package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Color {

	public Color(String stringVal) {
	}

	public Color(String stringVal, double opacity) {
	}

	public Color(String stringVal, double opacity, double brightness) {
	}

	public Color stringVal(String stringVal) {
	}

	public String stringVal() {
	}

	public Color opacity(Double opacity) {
	}

	public Double opacity() {
	}

	public Color brightness(Double brightness) {
	}

	public Double brightness() {
	}
}
