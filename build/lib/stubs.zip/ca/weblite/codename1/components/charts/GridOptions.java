package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class GridOptions {

	public GridOptions() {
	}

	public GridOptions show(Boolean show) {
	}

	public Boolean show() {
	}

	public GridOptions aboveData(boolean aboveData) {
	}

	public boolean aboveData() {
	}

	public GridOptions color(Color color) {
	}

	public Color color() {
	}

	public GridOptions backgroundColor(Color backgroundColor) {
	}

	public Color backgroundColor() {
	}

	public GridOptions margin(BorderWidths margin) {
	}

	public BorderWidths margin() {
	}

	public GridOptions labelMargin(Integer labelMargin) {
	}

	public Integer labelMargin() {
	}

	public GridOptions axisMargin(Integer axisMargin) {
	}

	public Integer axisMargin() {
	}

	public GridOptions borderWidth(BorderWidths borderWidth) {
	}

	public BorderWidths borderWidth() {
	}

	public GridOptions borderColor(BorderColors borderColor) {
	}

	public BorderColors borderColor() {
	}

	public GridOptions minBorderMargin(Integer minBorderMargin) {
	}

	public Integer minBorderMargin() {
	}

	public GridOptions clickable(Boolean clickable) {
	}

	public Boolean clickable() {
	}

	public GridOptions hoverable(Boolean hoverable) {
	}

	public Boolean hoverable() {
	}

	public GridOptions autoHighlight(Boolean autoHighlight) {
	}

	public Boolean autoHighlight() {
	}
}
