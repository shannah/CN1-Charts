package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Gradient extends Color {

	public Gradient() {
	}

	public Gradient add(Color color) {
	}

	public Gradient colors(java.util.List colors) {
	}

	public java.util.List colors() {
	}
}
