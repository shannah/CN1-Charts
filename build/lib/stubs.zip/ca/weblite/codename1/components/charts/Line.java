package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Line extends GeomElement {

	public Line() {
	}

	public Line zero(Boolean zero) {
	}

	public Boolean zero() {
	}

	public Line steps(Boolean steps) {
	}

	public Boolean steps() {
	}
}
