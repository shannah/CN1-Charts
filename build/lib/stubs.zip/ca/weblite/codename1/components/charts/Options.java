package ca.weblite.codename1.components.charts;


/**
 * 
 *  @author shannah
 */
public class Options {

	public Options() {
	}

	public Options series(Series series) {
	}

	public Series series() {
	}

	public Options legend(LegendOptions legend) {
	}

	public LegendOptions legend() {
	}

	public Options grid(GridOptions grid) {
	}

	public GridOptions grid() {
	}

	public Options xAxes(java.util.List xAxes) {
	}

	public java.util.List xAxes() {
	}

	public Options yAxes(java.util.List yAxes) {
	}

	public java.util.List yAxes() {
	}
}
